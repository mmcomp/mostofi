// var server_endpoint = 'https://apex.oracle.com/pls/apex/tracker/hr/';
//var server_endpoint = 'http://188.253.0.47:8081/ords/tracker/hr/';
var server_endpoint = 'http://mirsamie.com/mostofi/service/api/';
// var server_endpoint = 'http://188.253.0.47/mostofi/service/api/';