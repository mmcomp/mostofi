<?php
?>
    <footer class="footer">
        <!--<span class="text-left">-->
        <!--    <a href="http://mostofi-co.com">Mostofi Group</a> &copy;-->
        <!--</span>-->
        <span class="pull-right">
            تهیه شده توسط <a href="http://mostofi-co.com">گروه دکتر حمید مستوفی</a> &copy;
        </span>
    </footer>
