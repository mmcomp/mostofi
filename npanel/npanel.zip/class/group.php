<?php
class group extends base
{
    public function __construct($id=-1){
    parent::__construct('user_group',$id);
  }
}