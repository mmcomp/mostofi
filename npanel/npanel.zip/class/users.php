<?php
class users extends base
{
    public function __construct($id=-1){
    parent::__construct('users',$id);
  }
}